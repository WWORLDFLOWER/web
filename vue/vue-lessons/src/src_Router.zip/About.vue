<template>
    <div>
        <h1>[About]</h1>

        <router-link to="/about/us">About Us</router-link>
        <router-link to="/about/others">About Others</router-link>

        <p>
            <router-view></router-view>
        </p>
    </div>
</template>

<style scoped>
    h1{
        color:darkgreen;
        font: bold 40px COMIC sans MS;
    }
</style>