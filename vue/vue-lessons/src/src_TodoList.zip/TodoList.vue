<script>
import TodoInput from './TodoInput.vue'
import TodoItem from './TodoItem.vue'

export default {
    components: {
        TodoInput,
        TodoItem,
    },
    data(){
        return{
            tasks: [],
        }
    },
    methods: {
        addTask(item){
            this.tasks.push(item)
        },
        removeTask(index){
            this.tasks.splice(index,1)
        },
    },
}
</script>

<template>
    <div>
        <todo-input @abc="addTask"></todo-input>
        <!-- 
            下層(todo-input)傳遞到上層(todo-list) 
            -下層(todo-input): 發出 $emit('自訂事件')
            -上層(todo-list): 使用該事件 「v-on: 自訂事件」或「@該事件」接收資料
        -->
        <ol>
            <todo-item v-for="(task,index) in tasks" :xyz="task" @click.native="removeTask(index)"/>
            <!-- 
                上層(todo-list)傳遞到下層(todo-item)
                -上層(todo-list): 使用「v-bind: 自訂屬性」或「:自訂屬性」
                -下層(todo-item): 用 props: ['該屬性'] 接收
            -->
        </ol>
    </div>
</template>