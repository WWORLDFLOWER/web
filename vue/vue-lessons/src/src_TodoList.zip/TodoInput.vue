<script>
export default {
    data(){
        return{
            task: '',
        }
    },
    methods: {
        submitData(e){
            // e.preventDefault();  //取消預設值
            
            // this.$emit('自訂事件'[,傳值1,傳值2,...])
            this.$emit('abc', this.task)
            this.task = ''
        },
    },
}
</script>

<template>
    <form @submit.prevent="submitData">
        <input v-model="task">
        <button>submit</button>
    </form>
</template>