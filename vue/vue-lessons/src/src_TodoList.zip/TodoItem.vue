<template>
    <li class="theItem">{{xyz}}</li>
</template>

<script>
export default {
    props: ['xyz'],
}
</script>

<style lang="">
    .theItem{
        font: 18px Tahoma;
        background: #abc;
        padding: 5px;
        margin: 5px;
    }

    .theItem:hover{
        background: #cba;
        cursor: pointer;
    }
</style>