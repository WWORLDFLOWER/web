<template>
  <div>
      <button @click="addCount">Add</button>
      <h3>{{count}}</h3>
  </div>
</template>

<script>
import store from './store' 

export default {
     methods: {
        addCount(){
            // this.$store.commit('addStoreCount')
            store.commit('addStoreCount')
        },
    },
    computed: {
        count(){
            // return this.$store.state.count
            return store.state.count
        },
    },
}
</script>

