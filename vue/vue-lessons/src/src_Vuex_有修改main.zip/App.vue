<template>
  <div id="app"> 
    <button @click="addCount">Add</button>
    <h3>{{count}}</h3>
  </div>
</template>

<script>
export default {
  methods:{  //函數 "大部分" 放這裡
    // addCount(){
    //     this.count += 1
    // }

    addCount(){
        this.$store.commit('addStoreCount')
    },
  },
  computed: {
    count(){
        return this.$store.state.count
    },
  },
}
</script>
